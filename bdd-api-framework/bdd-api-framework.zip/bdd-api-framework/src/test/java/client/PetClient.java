package client;

import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class PetClient {

    private static final String BASE_URL = "https://petstore.swagger.io/v2";

    // =========================
    // COMMON REQUEST METHOD
    // =========================
    private Response request(String method, String endpoint, Object body) {

        switch (method.toUpperCase()) {

            case "GET":
                return given()
                        .when()
                        .get(BASE_URL + endpoint);

            case "POST":
                return given()
                        .header("Content-Type", "application/json")
                        .body(body)
                        .when()
                        .post(BASE_URL + endpoint);

            case "PUT":
                return given()
                        .header("Content-Type", "application/json")
                        .body(body)
                        .when()
                        .put(BASE_URL + endpoint);

            case "DELETE":
                return given()
                        .when()
                        .delete(BASE_URL + endpoint);

            default:
                throw new IllegalArgumentException("Invalid HTTP method: " + method);
        }
    }

    // =========================
    // PET APIs
    // =========================

    public Response getPetsByStatus(String status) {
        return request("GET", "/pet/findByStatus?status=" + status, null);
    }

    public Response createPet(String name, String status) {

        int id = generateRandomId();

        String body = "{\n" +
                "  \"id\": " + id + ",\n" +
                "  \"name\": \"" + name + "\",\n" +
                "  \"status\": \"" + status + "\"\n" +
                "}";

        return request("POST", "/pet", body);
    }

    public Response getPetById(int petId) {
        return request("GET", "/pet/" + petId, null);
    }

    public Response updatePet(int petId, String name, String status) {

        String body = "{\n" +
                "  \"id\": " + petId + ",\n" +
                "  \"name\": \"" + name + "\",\n" +
                "  \"status\": \"" + status + "\"\n" +
                "}";

        return request("PUT", "/pet", body);
    }

    public Response deletePet(int petId) {
        return request("DELETE", "/pet/" + petId, null);
    }

    // =========================
    // STORE APIs
    // =========================

    public Response getInventory() {
        return request("GET", "/store/inventory", null);
    }

    // =========================
    // USER APIs
    // =========================

    public Response createUser(String username, String email) {

        String body = "{\n" +
                "  \"username\": \"" + username + "\",\n" +
                "  \"firstName\": \"Test\",\n" +
                "  \"lastName\": \"User\",\n" +
                "  \"email\": \"" + email + "\",\n" +
                "  \"password\": \"12345\",\n" +
                "  \"phone\": \"1234567890\",\n" +
                "  \"userStatus\": 1\n" +
                "}";

        return request("POST", "/user", body);
    }

    public Response getUser(String username) {
        return request("GET", "/user/" + username, null);
    }

    public Response loginUser(String username, String password) {
        return request(
                "GET",
                "/user/login?username=" + username + "&password=" + password,
                null
        );
    }

    // =========================
    // TEST CASE 4 SUPPORT
    // =========================
    public Response getSoldPets() {
        return getPetsByStatus("sold");
    }

    // =========================
    // UTILITY
    // =========================
    private int generateRandomId() {
        return (int) (Math.random() * 100000);
    }
}