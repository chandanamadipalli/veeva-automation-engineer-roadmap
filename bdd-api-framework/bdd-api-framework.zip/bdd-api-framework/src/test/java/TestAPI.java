import io.restassured.RestAssured;
import org.junit.Test;

public class TestAPI {

    @Test
    public void testGetPet() {

        RestAssured
                .given()
                .when()
                .get("https://petstore.swagger.io/v2/pet/findByStatus?status=available")
                .then()
                .statusCode(200);

        System.out.println("API Test Passed ✅");
    }
}