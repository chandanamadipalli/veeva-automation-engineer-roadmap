Feature: Inventory Validation

  Scenario: Verify available pet count
    Given I fetch inventory data
    When I fetch pets by status "available"
    Then the available pet count should match