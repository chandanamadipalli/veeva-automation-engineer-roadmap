Feature: Pet API Automation

  Scenario: Full Pet Lifecycle (CRUD)
    Given I create a pet with name "Dog123" and status "available"
    Then the response status code should be 200

    When I fetch the pet by id
    Then the response status code should be 200

    When I update the pet status to "sold"
    Then the response status code should be 200

    When I delete the pet
    Then the response status code should be 200

Scenario: Verify pet appears in sold list

  Given I create a pet with name "Dog123" and status "available"
  When I update the pet status to "sold"
  And I fetch all sold pets
  Then the pet should be present in sold list