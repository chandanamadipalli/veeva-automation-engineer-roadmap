Feature: User API Negative Testing

  Scenario: Validate user API negative scenarios

    # Invalid email
    Given I create a user with invalid email "invalid_email"
    Then the response status code should be 200

    # Non-existing user
    When I fetch a non-existing user "noUser123"
    Then the response status code should be 404

    # Wrong login
    When I try to login with username "wrongUser" and password "wrongPass"
    Then the login should fail